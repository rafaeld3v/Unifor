
public class Aluno {
	
	private String nome;
	private int idade;
	private double media;
		
	public Aluno(String nome, int idade, double media)	{
		this.nome = nome;
		this.idade = idade;
		this.media = media;
	}

	public String getNome() {
		return nome;
	}

	public int getIdade() {
		return idade;
	}

	public double getMedia() {
		return media;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public void setMedia(double media) {
		this.media = media;
	}
	
	public void mostraAluno()	{
		System.out.println("Nome: " + nome);
		System.out.println("Idade: " + idade);
		System.out.println("M�dia: " + media);
	}
	
}
