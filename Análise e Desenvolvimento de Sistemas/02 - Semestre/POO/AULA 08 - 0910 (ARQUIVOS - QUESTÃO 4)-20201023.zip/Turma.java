
public class Turma {
	
	private Aluno[] alunos;
	private String curso;
	private int anoIngresso;
		
	public Turma (Aluno[] alunos, String curso, int anoIngresso)	{
		this.alunos = alunos;
		this.curso = curso;
		this.anoIngresso = anoIngresso;
	}

	public Aluno[] getAlunos() {
		return alunos;
	}

	public String getCurso() {
		return curso;
	}

	public int getAnoIngresso() {
		return anoIngresso;
	}

	public void setAlunos(Aluno[] alunos) {
		this.alunos = alunos;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public void setAnoIngresso(int anoIngresso) {
		this.anoIngresso = anoIngresso;
	}
	
	public void mostraTurma()	{
		for (int i = 0; i < alunos.length; i++)	{
			alunos[i].mostraAluno();
		}
		System.out.println("Curso: " + curso);
		System.out.println("Ano de ingresso: " + anoIngresso);
	}
	
	public double maiorMedia() {
		double maior = alunos[0].getMedia();
		for (int i = 0; i < alunos.length; i++)	{
			if (alunos[i].getMedia() > maior)	{
				maior = alunos[i].getMedia();
			}
		}
		return maior;
	}
	
	public double menorMedia() {
		double menor = alunos[0].getMedia();
		for (int i = 0; i < alunos.length; i++)	{
			if (alunos[i].getMedia() < menor)	{
				menor = alunos[i].getMedia();
			}
		}
		return menor;
	}
	
	public Aluno alunoMaiorMedia()	{
		double maior = alunos[0].getMedia();
		Aluno alunoMaiorMedia = alunos[0];
		for (int i = 0; i < alunos.length; i++)	{
			if (alunos[i].getMedia() > maior)	{
				maior = alunos[i].getMedia();
				alunoMaiorMedia = alunos[i];
			}
		}
		return alunoMaiorMedia;
	}
	
	public double mediaTurma()	{
		double soma = 0.0;
		for (int i = 0; i < alunos.length; i++)	{
			soma = soma + alunos[i].getMedia();
		}
		return soma/alunos.length;
	}
	
	public boolean tem10()	{
		for (int i = 0; i < alunos.length; i++)	{
			if (alunos[i].getMedia() == 10.0)	{
				return true;
			} 
		}
		return false;
	}
	
	public int quantidadeMaiorIgual7()	{
		int cnt = 0;
		for (int i = 0; i < alunos.length; i++)	{
			if (alunos[i].getMedia() >= 7.0)	{
				cnt++;
			} 
		}
		return cnt;
	}
	
}
