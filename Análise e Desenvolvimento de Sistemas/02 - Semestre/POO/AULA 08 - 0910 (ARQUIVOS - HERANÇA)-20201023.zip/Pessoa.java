package entidades;

public class Pessoa {
	
	protected String nome;
	protected String cpf;
	protected int anoNascimento;
	
	public Pessoa (String nome, String cpf, int anoNascimento)	{
		this.nome = nome;
		this.cpf = cpf;
		this.anoNascimento = anoNascimento;
	}

	public String getNome() {
		return nome;
	}

	public String getCpf() {
		return cpf;
	}

	public int getAnoNascimento() {
		return anoNascimento;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public void setAnoNascimento(int anoNascimento) {
		this.anoNascimento = anoNascimento;
	}
	
	public void mostra()	{
		System.out.println("Nome: " + nome);
		System.out.println("CPF: " + cpf);
		System.out.println("Ano de nascimento: " + anoNascimento);
	}
	
}
