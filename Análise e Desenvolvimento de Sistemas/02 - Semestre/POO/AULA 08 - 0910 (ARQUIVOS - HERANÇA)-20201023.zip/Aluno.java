package entidades;

public class Aluno extends Pessoa {
	
	protected int matricula;

	public Aluno(String nome, String cpf, int anoNascimento, int matricula) {
		super(nome, cpf, anoNascimento);
		this.matricula = matricula;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	
	public int calculaIdade(int anoAtual)	{
		return anoAtual - anoNascimento;
	}
	
}
