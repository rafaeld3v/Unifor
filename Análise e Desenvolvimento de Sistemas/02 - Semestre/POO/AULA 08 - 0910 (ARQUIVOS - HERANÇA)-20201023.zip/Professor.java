package entidades;

public class Professor extends Aluno {
	
	private int quantidadeDisciplinas;

	public Professor(String nome, String cpf, int anoNascimento, int matricula, int quantidadeDisciplinas) {
		super(nome, cpf, anoNascimento, matricula);
		this.quantidadeDisciplinas = quantidadeDisciplinas;
	}

	public int getQuantidadeDisciplinas() {
		return quantidadeDisciplinas;
	}

	public void setQuantidadeDisciplinas(int quantidadeDisciplinas) {
		this.quantidadeDisciplinas = quantidadeDisciplinas;
	}
	
	@Override
	public void mostra()	{
		System.out.println("Nome: " + nome);
		System.out.println("CPF: " + cpf);
		System.out.println("Ano de nascimento: " + anoNascimento);
		System.out.println("Matr�cula: " + matricula);
		System.out.println("Quantidade de disciplinas: " + quantidadeDisciplinas);
	}
	
}
