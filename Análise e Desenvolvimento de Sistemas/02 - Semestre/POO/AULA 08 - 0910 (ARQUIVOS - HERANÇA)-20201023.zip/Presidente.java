package entidades;

public class Presidente extends Funcionario {
	
	private int quantidadeAcoes;
	
	public Presidente(String nome, String cpf, double salario, int quantidadeAcoes)	{
		super(nome, cpf, salario);
		this.quantidadeAcoes = quantidadeAcoes;
	}

	public int getQuantidadeAcoes() {
		return quantidadeAcoes;
	}

	public void setQuantidadeAcoes(int quantidadeAcoes) {
		this.quantidadeAcoes = quantidadeAcoes;
	}
	
	@Override
	public double calculaBonus()	{
		return quantidadeAcoes + 0.10 * salario;
	}
	
	@Override
	public void mostra()	{
		System.out.println("Nome: " + nome);
		System.out.println("CPF: " + cpf);
		System.out.println("Sal�rio: " + salario);
		System.out.println("Quantidade de a��es: " + quantidadeAcoes);
	}
	
	// OS ATRIBUTOS P�BLICOS DA SUPERCLASSE S�O VIS�VEIS (!!) DENTRO DA SUBCLASSE
}
