package entidades;

public class Funcionario {
	
	protected String nome;
	protected String cpf;
	protected double salario;
	
	public Funcionario (String nome, String cpf, double salario)	{
		this.nome = nome;
		this.cpf = cpf;
		this.salario = salario;
	}

	public String getNome() {
		return nome;
	}

	public String getCpf() {
		return cpf;
	}

	public double getSalario() {
		return salario;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public double calculaBonus()	{
		return 0.05 * salario;
	}
	
	public void mostra()	{
		System.out.println("Nome: " + nome);
		System.out.println("CPF: " + cpf);
		System.out.println("Sal�rio: " + salario);
	}
	
}
