
public class Pagamento {
	double valorPago;
	
	public Pagamento(double valorPago){
		this.valorPago = valorPago;
	}

	public double getValorPago() {
		return valorPago;
	}
	
}
